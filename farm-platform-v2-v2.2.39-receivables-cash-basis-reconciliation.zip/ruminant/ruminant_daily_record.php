<?php require_once(dirname(__DIR__) . '/init.php'); ?>
<?php
require_once(__DIR__ . '/../config.php');
require_once(__DIR__ . '/../lib/daily_feed_sync.php');
requireLogin();

// Check access
if (!checkAccess('ruminant')) {
    header('Location: dashboard.php');
    exit();
}

$month = $_GET['month'] ?? date('Y-m');
$yearMonth = date('Y-m', strtotime($month));
$selectedCycleId = isset($_GET['cycle_id']) ? (int)$_GET['cycle_id'] : 0;
$monthSelectorDate = date('Y-m-d', strtotime($yearMonth . '-' . min((int)date('d'), (int)date('t', strtotime($yearMonth . '-01')))));
$canDeleteRecords = isPlatformOwner() || hasRole('farm_admin');
$canEditRecords = $canDeleteRecords || hasRole('ruminant_manager');
$managedTypes = ['cattle', 'goat', 'sheep', 'other'];
$tenantFarmId = requireCurrentFarmId();
$cycleEnabled = ($pdo->query("SHOW TABLES LIKE 'production_cycles'")->rowCount() > 0);
$activeCycles = [];
$selectedCycle = null;
if ($cycleEnabled) {
    $cycleStmt = $pdo->prepare("SELECT id, cycle_code, production_type FROM production_cycles WHERE farm_id = ? AND farm_type = 'ruminant' AND status = 'active' ORDER BY start_date DESC");
    $cycleStmt->execute([$tenantFarmId]);
    $activeCycles = $cycleStmt->fetchAll(PDO::FETCH_ASSOC);

$dailyFeedItemsStmt = $pdo->prepare("SELECT id, item_name, unit, current_stock, unit_cost FROM stock_items WHERE farm_id = ? AND is_active = 1 AND feed_category = 'ruminant' AND farm_type IN ('ruminant', 'both') ORDER BY item_name ASC");
$dailyFeedItemsStmt->execute([$tenantFarmId]);
$dailyFeedItems = $dailyFeedItemsStmt->fetchAll(PDO::FETCH_ASSOC);

    if ($selectedCycleId > 0) {
        $activeCycleIds = array_map(static function ($cycle) {
            return (int)$cycle['id'];
        }, $activeCycles);
        if (!in_array($selectedCycleId, $activeCycleIds, true)) {
            $selectedCycleId = 0;
        }
    }

    foreach ($activeCycles as $cycle) {
        if ((int)$cycle['id'] === $selectedCycleId) {
            $selectedCycle = $cycle;
            break;
        }
    }
}

// Handle delete request (admin/owner only)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_record']) && $canDeleteRecords) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) { http_response_code(419); exit('Invalid request token.'); }
    $recordId = (int)($_POST['record_id'] ?? 0);

    if ($recordId > 0) {
        $recordCheck = $pdo->prepare("SELECT animal_type FROM ruminant_daily_records WHERE id = ? AND farm_id = ?");
        $recordCheck->execute([$recordId, $tenantFarmId]);
        $record = $recordCheck->fetch();

        if ($record && in_array(strtolower($record['animal_type']), $managedTypes, true)) {
            try {
                $pdo->beginTransaction();
                delete_daily_feed_usage($pdo, $tenantFarmId, $recordId, 'daily_ruminant_record');
                $deleteStmt = $pdo->prepare("DELETE FROM ruminant_daily_records WHERE id = ? AND farm_id = ?");
                $deleteStmt->execute([$recordId, $tenantFarmId]);
                if ($deleteStmt->rowCount() !== 1) {
                    throw new RuntimeException('The daily record could not be deleted.');
                }
                $pdo->commit();
                $_SESSION['success'] = "Ruminant daily record deleted successfully.";
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $_SESSION['error'] = safeUserExceptionMessage($e, 'The daily record could not be deleted.');
            }
        } else {
            $_SESSION['error'] = "Daily record not found or you do not have permission to delete it.";
        }
    } else {
        $_SESSION['error'] = "Invalid daily record.";
    }

    header("Location: ruminant_daily_record.php?month=" . $month . "&cycle_id=" . (int)$selectedCycleId);
    exit();
}

// Get all records for the month
$query = "SELECT * FROM ruminant_daily_records WHERE farm_id = ? AND DATE_FORMAT(record_date, '%Y-%m') = ?";
$params = [$tenantFarmId, $yearMonth];
if ($cycleEnabled && $selectedCycleId > 0) {
    $query .= " AND cycle_id = ?";
    $params[] = $selectedCycleId;
}
$query .= " ORDER BY record_date, animal_type";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$records = $stmt->fetchAll();

// Group by animal type
$cycleMetaById = [];
foreach ($activeCycles as $cycle) {
    $cycleMetaById[(int)$cycle['id']] = $cycle;
}

$animalTypeTabs = [];
foreach ($records as $record) {
    $animalType = (string)$record['animal_type'];
    $cycleId = (int)($record['cycle_id'] ?? 0);
    $tabKey = strtolower($animalType);
    $tabLabel = $animalType;

    if ($cycleEnabled && $selectedCycleId === 0 && $cycleId > 0) {
        $cycleCode = $cycleMetaById[$cycleId]['cycle_code'] ?? ('Cycle #' . $cycleId);
        $tabKey = strtolower($animalType) . '-cycle-' . $cycleId;
        $tabLabel = $animalType . ' (' . $cycleCode . ')';
    }

    if (!isset($animalTypeTabs[$tabKey])) {
        $animalTypeTabs[$tabKey] = [
            'label' => $tabLabel,
            'animal_type' => $animalType,
            'records' => []
        ];
    }
    $animalTypeTabs[$tabKey]['records'][] = $record;
}

$recordsByCycle = [];
if ($cycleEnabled) {
    foreach ($records as $record) {
        $cycleId = (int)($record['cycle_id'] ?? 0);
        if ($cycleId <= 0) {
            continue;
        }
        if (!isset($recordsByCycle[$cycleId])) {
            $recordsByCycle[$cycleId] = [];
        }
        $recordsByCycle[$cycleId][] = $record;
    }
}

$recordsByDate = [];
foreach ($records as $record) {
    $recordDateKey = date('Y-m-d', strtotime($record['record_date']));
    if (!isset($recordsByDate[$recordDateKey])) {
        $recordsByDate[$recordDateKey] = [];
    }
    $recordsByDate[$recordDateKey][] = $record;
}

$showCycleTabs = false;
$showAnimalTypeTabs = true;

// Calculate totals
$monthlyTotals = [
    'opening_stock' => 0,
    'mortality' => 0,
    'feed_consumption' => 0,
    'water_consumption' => 0
];

foreach ($records as $record) {
    $monthlyTotals['opening_stock'] += $record['opening_stock'];
    $monthlyTotals['mortality'] += $record['mortality'];
    $monthlyTotals['feed_consumption'] += $record['feed_consumption_kg'];
    $monthlyTotals['water_consumption'] += $record['water_consumption_liters'];
}

$summaryTotals = $monthlyTotals;
if ($cycleEnabled && $selectedCycleId === 0) {
    $summaryStmt = $pdo->query("
        SELECT
            COALESCE(SUM(opening_stock), 0) AS opening_stock,
            COALESCE(SUM(mortality), 0) AS mortality,
            COALESCE(SUM(feed_consumption_kg), 0) AS feed_consumption,
            COALESCE(SUM(water_consumption_liters), 0) AS water_consumption
        FROM ruminant_daily_records
        WHERE farm_id = $tenantFarmId
    ");
    $summaryTotals = array_merge($summaryTotals, $summaryStmt->fetch(PDO::FETCH_ASSOC) ?: []);
}

$normalizeAnimalType = static function ($value) {
    $normalized = strtolower(trim((string)$value));
    $aliases = [
        'cattles' => 'cattle',
        'goats' => 'goat',
        'sheeps' => 'sheep',
        'rabbits' => 'other',
        'cats' => 'other',
        'dogs' => 'other'
    ];
    return $aliases[$normalized] ?? $normalized;
};

$latestClosingStock = '--';
if ($cycleEnabled && $selectedCycleId === 0) {
    $latestRuminantStmt = $pdo->query("
        SELECT t1.cycle_id, t1.opening_stock, t1.mortality
        FROM ruminant_daily_records t1
        INNER JOIN (
            SELECT cycle_id, MAX(record_date) AS max_date
            FROM ruminant_daily_records
            WHERE farm_id = $tenantFarmId AND cycle_id IS NOT NULL AND cycle_id > 0
            GROUP BY cycle_id
        ) t2 ON t1.cycle_id = t2.cycle_id AND t1.record_date = t2.max_date
        INNER JOIN production_cycles pc ON pc.id = t1.cycle_id
        WHERE t1.farm_id = $tenantFarmId AND pc.farm_id = $tenantFarmId AND pc.farm_type = 'ruminant' AND pc.status = 'active'
    ");
    $cycleClosingTotal = 0;
    foreach ($latestRuminantStmt->fetchAll(PDO::FETCH_ASSOC) as $cycleRecord) {
        $cycleClosingTotal += max(0, (float)$cycleRecord['opening_stock'] - (float)$cycleRecord['mortality']);
    }
    $latestClosingStock = $cycleClosingTotal;
} elseif ($cycleEnabled && $selectedCycleId > 0) {
    $latestRuminantStmt = $pdo->prepare("
        SELECT opening_stock, mortality
        FROM ruminant_daily_records
        WHERE cycle_id = ? AND farm_id = ?
        ORDER BY record_date DESC
        LIMIT 1
    ");
    $latestRuminantStmt->execute([$selectedCycleId, $tenantFarmId]);
    $latestRecord = $latestRuminantStmt->fetch();
    if ($latestRecord) {
        $latestClosingStock = max(0, (float)$latestRecord['opening_stock'] - (float)$latestRecord['mortality']);
    }
} elseif (!$cycleEnabled) {
    $latestRuminantStmt = $pdo->query("
        SELECT opening_stock, mortality
        FROM ruminant_daily_records
        WHERE farm_id = $tenantFarmId
        ORDER BY record_date DESC
        LIMIT 1
    ");
    $latestRecord = $latestRuminantStmt->fetch();
    if ($latestRecord) {
        $latestClosingStock = max(0, (float)$latestRecord['opening_stock'] - (float)$latestRecord['mortality']);
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_record'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) { http_response_code(419); exit('Invalid request token.'); }
    if ($cycleEnabled && count($activeCycles) > 1 && $selectedCycleId <= 0) {
        $_SESSION['error'] = 'Select an active ruminant production cycle before saving this record.';
        header('Location: ruminant_daily_record.php?month=' . urlencode($month));
        exit();
    }
    $parseNumeric = static function ($value): string { return str_replace(',', '', trim((string)$value)); };
    $nonNegative = static function ($value, string $label) use ($parseNumeric): float {
        $raw = $parseNumeric($value);
        if ($raw === '' || !is_numeric($raw) || (float)$raw < 0) throw new InvalidArgumentException($label . ' must be a valid non-negative number.');
        return (float)$raw;
    };
    $recordDate = trim((string)($_POST['record_date'] ?? ''));
    $dateObject = DateTime::createFromFormat('Y-m-d', $recordDate);
    $animalType = strtolower(trim((string)($_POST['animal_type'] ?? '')));
    $allowedAnimalTypes = ['cattle','goat','sheep','other'];
    if (!$dateObject || $dateObject->format('Y-m-d') !== $recordDate || !in_array($animalType, $allowedAnimalTypes, true)) {
        $_SESSION['error'] = 'Please provide a valid date and animal type.';
        header('Location: ruminant_daily_record.php?month=' . urlencode($month) . '&cycle_id=' . (int)$selectedCycleId);
        exit();
    }
    $cycleIdForSave = ($cycleEnabled && $selectedCycleId > 0) ? $selectedCycleId : null;
    if ($cycleIdForSave !== null) {
        $cycleCheck = $pdo->prepare("SELECT id, start_date, expected_end_date FROM production_cycles WHERE id = ? AND farm_id = ? AND farm_type = 'ruminant' AND status = 'active' LIMIT 1");
        $cycleCheck->execute([$cycleIdForSave, $tenantFarmId]);
        $cycle = $cycleCheck->fetch(PDO::FETCH_ASSOC);
        if (!$cycle || $recordDate < $cycle['start_date'] || (!empty($cycle['expected_end_date']) && $recordDate > $cycle['expected_end_date'])) {
            $_SESSION['error'] = 'The selected ruminant cycle is invalid for this record date.';
            header('Location: ruminant_daily_record.php?month=' . urlencode($month) . '&cycle_id=' . (int)$selectedCycleId);
            exit();
        }
    }
    try {
        $openingStock = (int)$nonNegative($_POST['opening_stock'] ?? 0, 'Opening stock');
        $mortality = (int)$nonNegative($_POST['mortality'] ?? 0, 'Mortality');
        $feedConsumption = $nonNegative($_POST['feed_consumption'] ?? 0, 'Feed consumption');
            $feedItemId = (int)($_POST['feed_item_id'] ?? 0);
            if ($feedConsumption > 0 && $feedItemId <= 0) {
                throw new InvalidArgumentException('Please select the feed item used for this daily consumption.');
            }
        $waterConsumption = $nonNegative($_POST['water_consumption'] ?? 0, 'Water consumption');
    } catch (InvalidArgumentException $e) {
        $_SESSION['error'] = safeUserExceptionMessage($e, 'The ruminant daily record could not be saved.');
        header('Location: ruminant_daily_record.php?month=' . urlencode($month) . '&cycle_id=' . (int)$selectedCycleId);
        exit();
    }
    if ($openingStock < 1) {
        $_SESSION['error'] = 'Opening stock must be greater than zero.';
        header('Location: ruminant_daily_record.php?month=' . urlencode($month) . '&cycle_id=' . (int)$selectedCycleId);
        exit();
    }
    if ($mortality > $openingStock) {
        $_SESSION['error'] = 'Mortality cannot exceed opening stock.';
        header('Location: ruminant_daily_record.php?month=' . urlencode($month) . '&cycle_id=' . (int)$selectedCycleId);
        exit();
    }
    if ($cycleIdForSave !== null) {
        $previousStmt = $pdo->prepare("SELECT opening_stock, mortality FROM ruminant_daily_records WHERE farm_id = ? AND cycle_id = ? AND LOWER(animal_type) = ? AND record_date < ? ORDER BY record_date DESC LIMIT 1");
        $previousStmt->execute([$tenantFarmId, $cycleIdForSave, $animalType, $recordDate]);
        $previous = $previousStmt->fetch(PDO::FETCH_ASSOC);
        if ($previous) {
            $expectedOpening = max(0, (int)$previous['opening_stock'] - (int)$previous['mortality']);
            if ($openingStock !== $expectedOpening) {
                $_SESSION['error'] = "Opening stock must match the previous day's closing herd (expected {$expectedOpening}).";
                header('Location: ruminant_daily_record.php?month=' . urlencode($month) . '&cycle_id=' . (int)$selectedCycleId);
                exit();
            }
        }
        $nextStmt = $pdo->prepare("SELECT opening_stock FROM ruminant_daily_records WHERE farm_id = ? AND cycle_id = ? AND LOWER(animal_type) = ? AND record_date > ? ORDER BY record_date ASC LIMIT 1");
        $nextStmt->execute([$tenantFarmId, $cycleIdForSave, $animalType, $recordDate]);
        $next = $nextStmt->fetch(PDO::FETCH_ASSOC);
        if ($next) {
            $newClosing = max(0, $openingStock - $mortality);
            if ((int)$next['opening_stock'] !== $newClosing) {
                $_SESSION['error'] = "This change would break herd continuity: the next record starts at {$next['opening_stock']}, but this record would close at {$newClosing}.";
                header('Location: ruminant_daily_record.php?month=' . urlencode($month) . '&cycle_id=' . (int)$selectedCycleId);
                exit();
            }
        }
    }

    $checkSql = "SELECT id FROM ruminant_daily_records WHERE farm_id = ? AND record_date = ? AND LOWER(animal_type) = ?";
    $checkParams = [$tenantFarmId, $recordDate, $animalType];
    if ($cycleIdForSave !== null) { $checkSql .= " AND cycle_id = ?"; $checkParams[] = $cycleIdForSave; }
    $checkStmt = $pdo->prepare($checkSql);
    $checkStmt->execute($checkParams);

     $existingRecordId = $checkStmt->fetchColumn();

        $pdo->beginTransaction();
        try {
        if ($existingRecordId) {
        $stmt = $pdo->prepare("UPDATE ruminant_daily_records SET
            opening_stock = ?, mortality = ?, feed_consumption_kg = ?, feed_item_id = ?, feed_consumption_unit = ?,
            water_consumption_liters = ?, other_details = ?, tag_no = ?,
            medications = ?, reproduction_details = ?, remarks = ?
            WHERE farm_id = ? AND record_date = ? AND LOWER(animal_type) = ?" . ($cycleIdForSave !== null ? " AND cycle_id = ?" : ""));
        $updateParams = [$openingStock, $mortality, $feedConsumption, $feedItemId ?: null, $feedItemId > 0 ? (string)($_POST['feed_consumption_unit'] ?? 'kg') : 'kg', $waterConsumption, $_POST['other_details'] ?? '', $_POST['tag_no'] ?? '', $_POST['medications'] ?? '', $_POST['reproduction_details'] ?? '', $_POST['remarks'] ?? '', $tenantFarmId, $recordDate, $animalType];
        if ($cycleIdForSave !== null) $updateParams[] = $cycleIdForSave;
        $stmt->execute($updateParams);
    } else {
        $stmt = $pdo->prepare("INSERT INTO ruminant_daily_records
            (farm_id, cycle_id, record_date, animal_type, opening_stock, mortality,
             feed_consumption_kg, feed_item_id, feed_consumption_unit, water_consumption_liters, other_details,
             tag_no, medications, reproduction_details, remarks, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$tenantFarmId, $cycleIdForSave, $recordDate, $animalType, $openingStock, $mortality, $feedConsumption, $feedItemId ?: null, $feedItemId > 0 ? (string)($_POST['feed_consumption_unit'] ?? 'kg') : 'kg', $waterConsumption, $_POST['other_details'] ?? '', $_POST['tag_no'] ?? '', $_POST['medications'] ?? '', $_POST['reproduction_details'] ?? '', $_POST['remarks'] ?? '', $_SESSION['user_id']]);
    }

    
        $dailyRecordId = $existingRecordId ? (int)$existingRecordId : (int)$pdo->lastInsertId();
        sync_daily_feed_usage($pdo, $tenantFarmId, $dailyRecordId, $feedItemId > 0 ? $feedItemId : null, $feedConsumption, $cycleIdForSave, $recordDate, 'ruminant', 'ruminant', 'daily_ruminant_record');
        $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $_SESSION['error'] = safeUserExceptionMessage($e, 'The daily record could not be saved.');
            header('Location: ruminant_daily_record.php?month=' . urlencode($month) . '&cycle_id=' . (int)$selectedCycleId);
            exit();
        }

$_SESSION['success'] = "Ruminant daily record saved successfully!";
    header("Location: ruminant_daily_record.php?month=" . $month . "&cycle_id=" . (int)$selectedCycleId);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php include(__DIR__ . '/../navbar_head.php'); ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ruminant Daily Record - Renee Farms</title>
</head>
<body class="ruminant-page">
    <?php include(__DIR__ . '/../navbar.php'); ?>

    <div class="container-fluid mt-4 poultry-shell">

        <div class="row">
            <div class="col-12">
                <div class="card poultry-panel">
                    <div class="card-header poultry-hero d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <h4 class="mb-0">
                            <i class="bi bi-shield-plus"></i>
                            Ruminant Daily Record - <?php echo date('F Y', strtotime($yearMonth)); ?>
                        </h4>
                        <div class="d-flex flex-wrap gap-2">
                            <input type="date" class="form-control js-calendar-input" id="monthSelector"
                                   value="<?php echo $monthSelectorDate; ?>" style="width: 200px;">
                            <button class="btn btn-primary" onclick="openRecordModal()">
                                <i class="bi bi-plus-circle"></i> Add Today's Record
                            </button>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="smart-poultry-note p-3 mb-4 d-flex gap-3 align-items-start">
                            <i class="bi bi-stars fs-4"></i>
                            <div>
                                <div class="fw-bold">Ruminant herd intelligence</div>
                                <div class="small">Track herd closing stock, mortality, feed and water trends across active cycles so health and grazing alerts can be automated next.</div>
                            </div>
                        </div>
                        <!-- Monthly Summary Cards -->
                        <div class="row mb-4">
                            <div class="col-6 col-md-3">
                                <div class="card text-white bg-primary">
                                    <div class="card-body text-center">
                                        <h6>Current Stock</h6>
                                        <h3><?php echo is_numeric($latestClosingStock) ? number_format($latestClosingStock) : $latestClosingStock; ?></h3>
                                        <small>Latest Closing</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-md-3">
                                <div class="card text-white bg-danger">
                                    <div class="card-body text-center">
                                        <h6>Mortality</h6>
                                        <h3><?php echo number_format($summaryTotals['mortality']); ?></h3>
                                        <small>Losses</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-md-3">
                                <div class="card text-white bg-warning">
                                    <div class="card-body text-center">
                                        <h6>Feed Used</h6>
                                        <h3><?php echo number_format($summaryTotals['feed_consumption'], 1); ?></h3>
                                        <small>Kg</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-md-3">
                                <div class="card text-white bg-info">
                                    <div class="card-body text-center">
                                        <h6>Water Used</h6>
                                        <h3><?php echo number_format($summaryTotals['water_consumption']); ?></h3>
                                        <small>Liters</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php if ($cycleEnabled): ?>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-bold">Active Ruminant Cycle</label>
                                <select class="form-select" id="activeCycleSelector">
                                    <option value="0" <?php echo ($selectedCycleId === 0) ? 'selected' : ''; ?>>All / Legacy records</option>
                                    <?php foreach ($activeCycles as $cycle): ?>
                                    <option value="<?php echo (int)$cycle['id']; ?>" <?php echo ((int)$selectedCycleId === (int)$cycle['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($cycle['cycle_code'] . ' (' . $cycle['production_type'] . ')'); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Monthly Calendar View -->
                        <div class="card mb-4">
                            <div class="card-header d-flex align-items-center justify-content-between">
                                <h5 class="mb-0"><i class="bi bi-calendar3 me-2"></i>Monthly Calendar View</h5>
                                <?php if (!($cycleEnabled && $selectedCycleId === 0)): ?>
                                <span class="badge text-bg-light border">Tap a day to add or edit</span>
                                <?php endif; ?>
                            </div>
                            <div class="card-body <?php echo ($cycleEnabled && $selectedCycleId === 0) ? 'calendar-legacy' : ''; ?>">
                                <div class="row">
                                    <?php
                                    $firstDay = date('N', strtotime($yearMonth . '-01'));
                                    $daysInMonth = date('t', strtotime($yearMonth));
                                    $currentDay = 1;
                                    $weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                                    ?>
                                    <?php foreach ($weekDays as $day): ?>
                                    <div class="col text-center fw-bold text-muted mb-2 calendar-weekday"><?php echo $day; ?></div>
                                    <?php endforeach; ?>

                                    <?php for ($i = 1; $i < $firstDay; $i++): ?>
                                    <div class="col"></div>
                                    <?php endfor; ?>

                                    <?php while ($currentDay <= $daysInMonth): ?>
                                        <?php if (($currentDay + $firstDay - 2) % 7 === 0 && $currentDay > 1): ?>
                                            </div><div class="row mb-2">
                                        <?php endif; ?>
                                        <?php
                                        $currentDate = $yearMonth . '-' . sprintf('%02d', $currentDay);
                                        $dayRecords = $recordsByDate[$currentDate] ?? [];
                                        $hasRecord = !empty($dayRecords);
                                        $hasMortality = false;
                                        $dayOpeningStock = 0;
                                        $dayMortality = 0;
                                        $dayFeedConsumption = 0;
                                        foreach ($dayRecords as $dayRecord) {
                                            $dayOpeningStock += (float)$dayRecord['opening_stock'];
                                            $dayMortality += (float)$dayRecord['mortality'];
                                            $dayFeedConsumption += (float)$dayRecord['feed_consumption_kg'];
                                            if ((int)$dayRecord['mortality'] > 0) {
                                                $hasMortality = true;
                                            }
                                        }
                                        $isCalendarEditable = !($cycleEnabled && $selectedCycleId === 0);
                                        $dayClasses = 'calendar-day border rounded p-2 text-center w-100';
                                        if ($isCalendarEditable) {
                                            $dayClasses .= ' add-record-btn';
                                        } else {
                                            $dayClasses .= ' no-action';
                                        }
                                        if ($hasRecord) $dayClasses .= ' has-record';
                                        if ($hasMortality) $dayClasses .= ' has-mortality';
                                        ?>
                                        <div class="col p-1">
                                            <button type="button"
                                                    class="<?php echo $dayClasses; ?>"
                                                    data-record-date="<?php echo htmlspecialchars($currentDate); ?>"
                                                    data-cycle-animal-type="<?php echo htmlspecialchars($normalizeAnimalType($selectedCycle['production_type'] ?? ($dayRecords[0]['animal_type'] ?? ''))); ?>">
                                                <div class="calendar-date"><?php echo $currentDay; ?></div>
                                                <?php if ($hasRecord): ?>
                                                    <div class="calendar-meta"><?php echo count($dayRecords); ?> record(s)</div>
                                                    <?php if (!($cycleEnabled && $selectedCycleId === 0)): ?>
                                                    <div class="d-flex flex-wrap gap-1 justify-content-center mt-1">
                                                        <span class="badge text-bg-primary">O/S: <?php echo number_format($dayOpeningStock, 0); ?></span>
                                                        <span class="badge text-bg-danger">Mort: <?php echo number_format($dayMortality, 0); ?></span>
                                                        <span class="badge text-bg-success">Feed: <?php echo number_format($dayFeedConsumption, 1); ?></span>
                                                    </div>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <div class="calendar-meta">No record</div>
                                                <?php endif; ?>
                                            </button>
                                        </div>
                                        <?php $currentDay++; ?>
                                    <?php endwhile; ?>
                                </div>
                            </div>
                        </div>
                        <!-- Detailed Daily Records -->
                        <div class="card mb-3">
                            <div class="card-header">
                                <h5 class="mb-0">Detailed Daily Records</h5>
                            </div>
                        </div>

                        <!-- Animal Type Tabs -->
                        <ul class="nav nav-tabs mb-4" id="animalTabs">
                            <?php if ($showCycleTabs): ?>
                                <?php foreach ($activeCycles as $cycleIndex => $cycle): ?>
                                <li class="nav-item">
                                    <a class="nav-link <?php echo ($cycleIndex === 0 && !$showAnimalTypeTabs) ? 'active' : ''; ?>" data-bs-toggle="tab" href="#cycle-<?php echo (int)$cycle['id']; ?>">
                                        <?php echo htmlspecialchars($cycle['cycle_code']); ?>
                                    </a>
                                </li>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            <?php if ($showAnimalTypeTabs): ?>
                            <?php $animalTabIndex = 0; foreach ($animalTypeTabs as $tabKey => $animalTab): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo ($animalTabIndex === 0) ? 'active' : ''; ?>" data-bs-toggle="tab" href="#<?php echo htmlspecialchars(strtolower(str_replace(' ', '', $tabKey))); ?>">
                                    <?php echo htmlspecialchars($animalTab['label']); ?>
                                </a>
                            </li>
                            <?php $animalTabIndex++; ?>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </ul>

                        <!-- Tab Content -->
                        <div class="tab-content">
                            <?php if ($showCycleTabs): ?>
                                <?php foreach ($activeCycles as $cycleIndex => $cycle): ?>
                                <div class="tab-pane fade <?php echo ($cycleIndex === 0 && !$showAnimalTypeTabs) ? 'show active' : ''; ?>" id="cycle-<?php echo (int)$cycle['id']; ?>">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover poultry-table">
                                            <thead class="table-dark">
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Animal Type</th>
                                                    <th>Opening Stock</th>
                                                    <th>Mortality</th>
                                                    <th>Feed (kg)</th>
                                                    <th>Water (L)</th>
                                                    <th>Tag No</th>
                                                    <th>Reproduction</th>
                                                    <th>Remarks</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $cycleRecords = $recordsByCycle[(int)$cycle['id']] ?? []; ?>
                                                <?php if (empty($cycleRecords)): ?>
                                                <tr>
                                                    <td colspan="9" class="text-center text-muted py-4">
                                                        No records found for <?php echo htmlspecialchars($cycle['cycle_code']); ?> in this month
                                                    </td>
                                                </tr>
                                                <?php else: ?>
                                                    <?php foreach ($cycleRecords as $record): ?>
                                                    <tr>
                                                        <td><strong><?php echo date('d/m/Y', strtotime($record['record_date'])); ?></strong></td>
                                                        <td><span class="badge bg-info"><?php echo htmlspecialchars($record['animal_type']); ?></span></td>
                                                        <td><?php echo (int)$record['opening_stock']; ?></td>
                                                        <td class="text-danger fw-bold"><?php echo (int)$record['mortality']; ?></td>
                                                        <td><?php echo htmlspecialchars($record['feed_consumption_kg']); ?></td>
                                                        <td><?php echo number_format((float)$record['water_consumption_liters']); ?></td>
                                                        <td><?php echo htmlspecialchars($record['tag_no'] ?: '--'); ?></td>
                                                        <td><?php echo htmlspecialchars($record['reproduction_details'] ? substr($record['reproduction_details'], 0, 20) . '...' : '--'); ?></td>
                                                        <td><?php echo htmlspecialchars($record['remarks'] ? substr($record['remarks'], 0, 20) . '...' : '--'); ?></td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php endif; ?>

                            <!-- Individual Animal Type Tabs -->
                            <?php if ($showAnimalTypeTabs): ?>
                            <?php $animalPaneIndex = 0; foreach ($animalTypeTabs as $tabKey => $animalTab):
                                $animalType = $animalTab['animal_type'];
                                $typeRecords = $animalTab['records'];
                                $typeKey = strtolower($animalType);
                                $isEditableType = in_array($typeKey, $managedTypes, true);
                                $typeTotals = [
                                    'closing_stock' => 0,
                                    'mortality' => 0,
                                    'feed_consumption' => 0,
                                    'water_consumption' => 0
                                ];

                                foreach ($typeRecords as $record) {
                                    $closingStock = max(0, $record['opening_stock'] - $record['mortality']);
                                    $typeTotals['closing_stock'] = $closingStock;
                                    $typeTotals['mortality'] += $record['mortality'];
                                    $typeTotals['feed_consumption'] += $record['feed_consumption_kg'];
                                    $typeTotals['water_consumption'] += $record['water_consumption_liters'];
                                }
                            ?>
                            <div class="tab-pane fade <?php echo ($animalPaneIndex === 0) ? 'show active' : ''; ?>" id="<?php echo htmlspecialchars(strtolower(str_replace(' ', '', $tabKey))); ?>">
                                <!-- Type Records Table -->
                                <div class="table-responsive">
                                    <table class="table table-striped poultry-table">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Opening Stock</th>
                                                <th>Mortality</th>
                                                <th>Feed (kg)</th>
                                                <th>Water (L)</th>
                                                <th>Tag No</th>
                                                <th>Medications</th>
                                                <th>Reproduction</th>
                                                <th>Other Details</th>
                                                <th>Remarks</th>
                                                <?php if ($canEditRecords && $isEditableType): ?>
                                                <th>Actions</th>
                                                <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($typeRecords as $record):
                                                $closingStock = $record['opening_stock'] - $record['mortality'];
                                            ?>
                                            <tr>
                                                <td><?php echo date('d/m/Y', strtotime($record['record_date'])); ?></td>
                                                <td><?php echo $record['opening_stock']; ?></td>
                                                <td class="text-danger fw-bold">
                                                    <?php echo $record['mortality']; ?>
                                                    <small class="d-block text-muted">
                                                        Closing: <?php echo $closingStock; ?>
                                                    </small>
                                                </td>
                                                <td><?php echo $record['feed_consumption_kg']; ?></td>
                                                <td><?php echo number_format($record['water_consumption_liters']); ?></td>
                                                <td><?php echo $record['tag_no'] ?: '--'; ?></td>
                                                <td>
                                                    <?php if ($record['medications']): ?>
                                                    <small><?php echo substr($record['medications'], 0, 15); ?>...</small>
                                                    <?php else: ?>
                                                    <span class="text-muted">--</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if ($record['reproduction_details']): ?>
                                                    <small><?php echo substr($record['reproduction_details'], 0, 15); ?>...</small>
                                                    <?php else: ?>
                                                    <span class="text-muted">--</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if ($record['other_details']): ?>
                                                    <small><?php echo substr($record['other_details'], 0, 15); ?>...</small>
                                                    <?php else: ?>
                                                    <span class="text-muted">--</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if ($record['remarks']): ?>
                                                    <small class="text-muted"><?php echo substr($record['remarks'], 0, 15); ?>...</small>
                                                    <?php else: ?>
                                                    <span class="text-muted">--</span>
                                                    <?php endif; ?>
                                                </td>
                                                <?php if ($canEditRecords && $isEditableType): ?>
                                                <td>
                                                      <div class="d-flex flex-wrap gap-2">
                                                          <button class="btn btn-sm btn-outline-primary edit-record-btn"
                                                                  title="Edit Record"
                                                                  data-record-date="<?php echo htmlspecialchars($record['record_date']); ?>"
                                                                  data-selected-date="<?php echo htmlspecialchars($record['record_date']); ?>"
                                                                  data-animal-type="<?php echo htmlspecialchars($record['animal_type']); ?>"
                                                                  data-opening-stock="<?php echo htmlspecialchars($record['opening_stock']); ?>"
                                                                  data-mortality="<?php echo htmlspecialchars($record['mortality']); ?>"
                                                                  data-feed-consumption="<?php echo htmlspecialchars($record['feed_consumption_kg']); ?>"
                                                                  data-feed-item-id="<?php echo (int)($record['feed_item_id'] ?? 0); ?>"
                                                                  data-water-consumption="<?php echo htmlspecialchars($record['water_consumption_liters']); ?>"
                                                                  data-tag-no="<?php echo htmlspecialchars($record['tag_no']); ?>"
                                                                  data-medications="<?php echo htmlspecialchars($record['medications']); ?>"
                                                                  data-reproduction-details="<?php echo htmlspecialchars($record['reproduction_details']); ?>"
                                                                  data-other-details="<?php echo htmlspecialchars($record['other_details']); ?>"
                                                                  data-remarks="<?php echo htmlspecialchars($record['remarks']); ?>">
                                                              <i class="bi bi-pencil"></i>
                                                          </button>
                                                        <?php if ($canDeleteRecords): ?>
                                                        <form method="POST" class="d-inline" data-confirm="Delete this record? This action cannot be undone." data-confirm-title="Delete daily record?" data-confirm-button="Delete"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES); ?>">
                                                            <input type="hidden" name="record_id" value="<?php echo $record['id']; ?>">
                                                            <button type="submit" name="delete_record" class="btn btn-sm btn-outline-danger">
                                                                <i class="bi bi-trash"></i>
                                                            </button>
                                                        </form>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <?php endif; ?>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                        <tfoot class="table-secondary">
                                            <tr>
                                                <td><strong>TOTAL</strong></td>
                                                <td>--</td>
                                                <td class="text-danger fw-bold"><?php echo $typeTotals['mortality']; ?></td>
                                                <td class="fw-bold"><?php echo number_format($typeTotals['feed_consumption'], 2); ?></td>
                                                <td class="fw-bold"><?php echo number_format($typeTotals['water_consumption']); ?></td>
                                                <td colspan="<?php echo ($canEditRecords && $isEditableType) ? '6' : '5'; ?>">Monthly Summary</td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                            <?php $animalPaneIndex++; ?>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Record Modal -->
    <div class="modal fade" id="recordModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form method="POST" id="recordForm"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES); ?>">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalTitle">Ruminant Daily Record</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="record_date" id="recordDate">
                        <input type="hidden" name="animal_type" id="animalTypeHidden">

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Date</label>
                                <input type="date" class="form-control" id="selectedDate"
                                       onchange="checkExistingRecord()" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Animal Type</label>
                                <select class="form-control" id="animalType" required>
                                    <option value="">Select Animal Type</option>
                                    <option value="cattle">Cattle</option>
                                    <option value="goat">Goat</option>
                                    <option value="sheep">Sheep</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Opening Stock</label>
                                <input type="number" name="opening_stock" class="form-control"
                                       id="openingStock" min="0" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Mortality</label>
                                <input type="number" name="mortality" class="form-control"
                                       id="mortality" min="0" value="0">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label id="feedConsumptionLabel">Feed Consumption (kg)</label>
                                <input type="number" name="feed_consumption" class="form-control"
                                       id="feedConsumption" step="0.1" min="0" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Feed Item</label>
                                <select name="feed_item_id" id="feedItemId" class="form-select">
                                    <option value="">Select active feed item</option>
                                    <?php foreach ($dailyFeedItems as $feedItem): ?>
                                        <option value="<?php echo (int)$feedItem['id']; ?>" data-unit="<?php echo htmlspecialchars($feedItem['unit'], ENT_QUOTES); ?>">
                                            <?php echo htmlspecialchars($feedItem['item_name']); ?> (<?php echo htmlspecialchars($feedItem['unit']); ?> — <?php echo number_format((float)$feedItem['current_stock'], 2); ?> available)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="hidden" name="feed_consumption_unit" id="feedConsumptionUnit" value="kg">
                                <small class="text-muted">Select the active feed used for this day's consumption. Inventory stock is updated automatically.</small>
                            </div>
<div class="col-md-6 mb-3">
                                <label>Water Consumption (liters)</label>
                                <input type="number" name="water_consumption" class="form-control"
                                       id="waterConsumption" step="0.1" min="0" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Tag Number</label>
                                <input type="text" name="tag_no" class="form-control"
                                       id="tagNo" placeholder="Optional tag number">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Medications</label>
                                <input type="text" name="medications" class="form-control"
                                       id="medications" placeholder="Medications given">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label>Reproduction Details</label>
                            <textarea name="reproduction_details" class="form-control"
                                     id="reproductionDetails" rows="2"
                                     placeholder="Births, pregnancies, etc."></textarea>
                        </div>

                        <div class="mb-3">
                            <label>Other Details</label>
                            <textarea name="other_details" class="form-control"
                                     id="otherDetails" rows="2"></textarea>
                        </div>

                        <div class="mb-3">
                            <label>Remarks / Causes of Mortality</label>
                            <textarea name="remarks" class="form-control"
                                     id="remarks" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="save_record" class="btn btn-primary">Save Record</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

     <script src="<?php echo BASE_URL; ?><?php echo versioned_asset('/assets/vendor/jquery/jquery.min.js'); ?>">
    const feedItemSelector = document.getElementById('feedItemId');
    if (feedItemSelector) {
        feedItemSelector.addEventListener('change', function () {
            const option = this.options[this.selectedIndex];
            const unit = option ? (option.dataset.unit || 'kg') : 'kg';
            const unitInput = document.getElementById('feedConsumptionUnit');
            if (unitInput) unitInput.value = unit;
            const label = document.getElementById('feedConsumptionLabel');
            if (label) label.textContent = 'Feed Consumption (' + unit + ')';
        });
    }
</script>
    <script src="<?php echo BASE_URL; ?><?php echo versioned_asset('/assets/vendor/bootstrap5/js/bootstrap.bundle.min.js'); ?>"></script>
    <script src="<?php echo BASE_URL; ?><?php echo versioned_asset('/assets/vendor/datatables/js/jquery.dataTables.min.js'); ?>"></script>
    <script src="<?php echo BASE_URL; ?><?php echo versioned_asset('/assets/vendor/datatables/js/dataTables.bootstrap5.min.js'); ?>"></script>
    <script src="<?php echo BASE_URL; ?><?php echo versioned_asset('/assets/vendor/datatables-responsive/js/dataTables.responsive.min.js'); ?>"></script>
    <script src="<?php echo BASE_URL; ?><?php echo versioned_asset('/assets/js/main.js'); ?>"></script>
 <script src="<?php echo BASE_URL; ?>/assets/js/edit-modal.js"></script>

<!--
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    -->
    <script>
    // Month selector
    document.getElementById('monthSelector').addEventListener('blur', function() {
        window.location.href = 'ruminant_daily_record.php?month=' + this.value.substring(0, 7) + '&cycle_id=<?php echo (int)$selectedCycleId; ?>';
    });
    const cycleSelector = document.getElementById('activeCycleSelector');
    if (cycleSelector) {
        cycleSelector.addEventListener('change', function () {
            window.location.href = 'ruminant_daily_record.php?month=<?php echo $yearMonth; ?>&cycle_id=' + this.value;
        });
    }

    const selectedCycleId = <?php echo (int)$selectedCycleId; ?>;
    const selectedCycleAnimalType = <?php echo json_encode($normalizeAnimalType($selectedCycle['production_type'] ?? '')); ?>;
    const validRuminantTypes = ['cattle', 'goat', 'sheep', 'other'];

    function getSelectedCycleAnimalType() {
        const animalType = String(selectedCycleAnimalType || '').toLowerCase();
        return selectedCycleId > 0 && validRuminantTypes.includes(animalType) ? animalType : null;
    }

    function parseNumericInput(value) {
        if (value === null || value === undefined) return '';
        return String(value).replace(/,/g, '').trim();
    }

    // Open modal for new record
    function openRecordModal(date = null, animalType = null, hasRecord = false) {
        const modalElement = document.getElementById('recordModal');
        const modal = bootstrap.Modal.getOrCreateInstance(modalElement);
        const today = new Date().toISOString().split('T')[0];
        const selectedDate = date || today;
        const defaultAnimalType = animalType || getSelectedCycleAnimalType();

        resetForm();
        document.getElementById('animalType').disabled = false;

        document.getElementById('selectedDate').value = selectedDate;
        document.getElementById('recordDate').value = selectedDate;

        if (defaultAnimalType) {
            document.getElementById('animalType').value = defaultAnimalType;
            document.getElementById('animalTypeHidden').value = defaultAnimalType;
        }

        if (hasRecord) {
            document.getElementById('modalTitle').textContent = 'Edit Record';
        } else {
            document.getElementById('modalTitle').textContent = "Add Today's Record";
            if (defaultAnimalType) {
                loadExistingRecordOrPreviousStock(selectedDate, defaultAnimalType);
            }
        }

        modal.show();
    }

    function loadExistingRecordOrPreviousStock(date, animalType) {
        if (selectedCycleId <= 0 || !date || !animalType) {
            document.getElementById('modalTitle').textContent = "Add Today's Record";
            return;
        }

        const params = new URLSearchParams({
            date: date,
            animal_type: animalType
        });

        fetch(`../api/check_ruminant_record.php?cycle_id=${selectedCycleId}&${params}`)
            .then(response => response.json())
            .then(data => {
                if (data.exists) {
                    document.getElementById('modalTitle').textContent = 'Edit Record';
                    document.getElementById('animalType').disabled = true;
                    fetchRecordData(date, animalType);
                    return;
                }

                document.getElementById('modalTitle').textContent = "Add Today's Record";
                document.getElementById('animalType').disabled = false;
                fetchPreviousStock(date, animalType);
            })
            .catch(error => console.error(error));
    }

    const canEditRetrievedOpeningStock = <?php echo (isPlatformOwner() || hasRole('farm_admin')) ? 'true' : 'false'; ?>;
    function lockRetrievedOpeningStock() {
        if (!canEditRetrievedOpeningStock) {
            document.getElementById('openingStock').readOnly = true;
        }
    }
    function unlockOpeningStock() {
        document.getElementById('openingStock').readOnly = false;
    }

    // Fetch record data
    function fetchRecordData(date, animalType) {
        const params = new URLSearchParams({
            date: date,
            animal_type: animalType
        });

        fetch(`../api/get_record.php?type=ruminant&cycle_id=${selectedCycleId}&${params}`)
            .then(response => response.json())
            .then(payload => {
                if (payload && payload.success === false) {
                    throw new Error(payload.error || 'Failed to fetch record');
                }
                const data = payload ? payload.data : null;
                if (data) {
                    document.getElementById('openingStock').value = parseNumericInput(data.opening_stock || '');
                    document.getElementById('mortality').value = parseNumericInput(data.mortality || 0);
                    document.getElementById('feedConsumption').value = parseNumericInput(data.feed_consumption_kg || '');
                    if (document.getElementById('feedItemId')) { document.getElementById('feedItemId').value = data.feed_item_id || ''; document.getElementById('feedConsumptionUnit').value = data.feed_consumption_unit || 'kg'; const label = document.getElementById('feedConsumptionLabel'); if (label) label.textContent = 'Feed Consumption (' + (data.feed_consumption_unit || 'kg') + ')'; }
                    document.getElementById('waterConsumption').value = parseNumericInput(data.water_consumption_liters || '');
                    document.getElementById('tagNo').value = data.tag_no || '';
                    document.getElementById('medications').value = data.medications || '';
                    document.getElementById('reproductionDetails').value = data.reproduction_details || '';
                    document.getElementById('otherDetails').value = data.other_details || '';
                    document.getElementById('remarks').value = data.remarks || '';
                }
            })
            .catch(error => {
                console.error(error);
            });
    }


    function fetchPreviousStock(date, animalType) {
        const params = new URLSearchParams({
            type: 'ruminant',
            date: date,
            animal_type: animalType,
            cycle_id: selectedCycleId
        });

        fetch(`../api/get_previous_stock.php?${params}`)
            .then(response => response.json())
            .then(payload => {
                if (payload && payload.closing_stock !== null && payload.closing_stock !== undefined) {
                    document.getElementById('openingStock').value = payload.closing_stock > 0 ? payload.closing_stock : '';
                    lockRetrievedOpeningStock();
                }
            })
            .catch(error => console.error(error));
    }

    // Check existing record
    function checkExistingRecord() {
        const date = document.getElementById('selectedDate').value;
        const animalType = document.getElementById('animalType').value;

        document.getElementById('recordDate').value = date;
        document.getElementById('animalTypeHidden').value = animalType;

        if (!date || !animalType) return;
        if (selectedCycleId <= 0) {
            resetForm();
            document.getElementById('selectedDate').value = date;
            document.getElementById('recordDate').value = date;
            document.getElementById('animalType').value = animalType;
            document.getElementById('animalTypeHidden').value = animalType;
            return;
        }

        const params = new URLSearchParams({
            date: date,
            animal_type: animalType
        });

        fetch(`../api/check_ruminant_record.php?cycle_id=${selectedCycleId}&${params}`)
            .then(response => response.json())
            .then(data => {
                if (data.exists) {
                    document.getElementById('modalTitle').textContent = 'Edit Record';
                    document.getElementById('animalType').disabled = true;
                    fetchRecordData(date, animalType);
                } else {
                    document.getElementById('modalTitle').textContent = "Add Today's Record";
                    document.getElementById('animalType').disabled = false;
                    const currentDate = date;
                    const currentAnimalType = animalType;
                    resetForm();
                    document.getElementById('selectedDate').value = currentDate;
                    document.getElementById('recordDate').value = currentDate;
                    document.getElementById('animalType').value = currentAnimalType;
                    document.getElementById('animalTypeHidden').value = currentAnimalType;
                    fetchPreviousStock(currentDate, currentAnimalType);
                }
            });
    }

    document.getElementById('animalType').addEventListener('change', () => {
        document.getElementById('animalTypeHidden').value = document.getElementById('animalType').value;
        checkExistingRecord();
    });

    // Reset form
    function resetForm() {
        unlockOpeningStock();
        document.getElementById('recordForm').reset();
        document.getElementById('mortality').value = 0;
        document.getElementById('recordDate').value = document.getElementById('selectedDate').value;
        document.getElementById('animalTypeHidden').value = document.getElementById('animalType').value;
    }

    document.getElementById('recordForm').addEventListener('submit', () => {
        ['openingStock', 'mortality', 'feedConsumption', 'waterConsumption'].forEach((fieldId) => {
            const input = document.getElementById(fieldId);
            if (input) {
                input.value = parseNumericInput(input.value);
            }
        });
    });

    attachEditModal({
        buttonSelector: '.edit-record-btn',
        modalSelector: '#recordModal',
        fieldMap: {
            recordDate: '#recordDate',
            selectedDate: '#selectedDate',
            animalType: '#animalType',
            openingStock: '#openingStock',
            mortality: '#mortality',
            feedConsumption: '#feedConsumption',
            feedItemId: '#feedItemId',
            waterConsumption: '#waterConsumption',
            tagNo: '#tagNo',
            medications: '#medications',
            reproductionDetails: '#reproductionDetails',
            otherDetails: '#otherDetails',
            remarks: '#remarks'
        },
        onShow: ({ modalElement, data }) => {
            modalElement.querySelector('#modalTitle').textContent = 'Edit Record';
            modalElement.querySelector('#animalType').disabled = true;
            modalElement.querySelector('#animalTypeHidden').value = data.animalType || '';
        }
    });

    document.querySelectorAll('.add-record-btn').forEach(button => {
        button.addEventListener('click', () => {
            const cycleAnimalType = (button.dataset.cycleAnimalType || '').toLowerCase();
            const animalType = validRuminantTypes.includes(cycleAnimalType) ? cycleAnimalType : null;
            openRecordModal(button.dataset.recordDate, animalType, false);
        });
    });

    // Show messages
    </script>
</body>
</html>
