<?php require_once(dirname(__DIR__) . '/init.php'); ?>
<?php
require_once(__DIR__ . '/../config.php');
require_once(__DIR__ . '/../lib/daily_feed_sync.php');
requireLogin();

// Check access
$userType = getUserType();
if (!checkAccess('poultry')) {
    header('Location: dashboard.php');
    exit();
}
$canEdit = isPlatformOwner() || hasRole('farm_admin', 'poultry_manager');
$canDelete = isPlatformOwner() || hasRole('farm_admin');

$month = $_GET['month'] ?? date('Y-m');
$yearMonth = date('Y-m', strtotime($month));
$selectedCycleId = isset($_GET['cycle_id']) ? (int)$_GET['cycle_id'] : 0;
$monthSelectorDate = date('Y-m-d', strtotime($yearMonth . '-' . min((int)date('d'), (int)date('t', strtotime($yearMonth . '-01')))));

$tenantFarmId = requireCurrentFarmId();
$cycleEnabled = ($pdo->query("SHOW TABLES LIKE 'production_cycles'")->rowCount() > 0);
$activeCycles = [];
if ($cycleEnabled) {
    $cycleStmt = $pdo->prepare("SELECT id, cycle_code FROM production_cycles WHERE farm_id = ? AND farm_type = 'poultry' AND production_type = 'broiler' AND status = 'active' ORDER BY start_date DESC");
    $cycleStmt->execute([$tenantFarmId]);
    $activeCycles = $cycleStmt->fetchAll(PDO::FETCH_ASSOC);

$dailyFeedItemsStmt = $pdo->prepare("SELECT id, item_name, unit, current_stock, unit_cost FROM stock_items WHERE farm_id = ? AND is_active = 1 AND feed_category = 'broiler' AND farm_type IN ('poultry', 'both') ORDER BY item_name ASC");
$dailyFeedItemsStmt->execute([$tenantFarmId]);
$dailyFeedItems = $dailyFeedItemsStmt->fetchAll(PDO::FETCH_ASSOC);

}

// Get records for the month
$records = [];
$query = "SELECT * FROM broiler_daily_records WHERE farm_id = ? AND DATE_FORMAT(record_date, '%Y-%m') = ?";
$params = [$tenantFarmId, $yearMonth];
if ($cycleEnabled && $selectedCycleId > 0) {
    $query .= " AND cycle_id = ?";
    $params[] = $selectedCycleId;
}
$query .= " ORDER BY record_date";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$records = $stmt->fetchAll();

// Get latest closing stock from broiler mortality table
$broilerClosingStock = null;
$latestBroilerRecord = null;
if ($cycleEnabled && $selectedCycleId === 0) {
    $latestBroilerStmt = $pdo->query("
        SELECT t1.cycle_id, t1.opening_stock, t1.mortality
        FROM broiler_daily_records t1
        INNER JOIN (
            SELECT cycle_id, MAX(record_date) AS max_date
            FROM broiler_daily_records
            WHERE farm_id = $tenantFarmId AND cycle_id IS NOT NULL AND cycle_id > 0
            GROUP BY cycle_id
        ) t2 ON t1.cycle_id = t2.cycle_id AND t1.record_date = t2.max_date
        INNER JOIN production_cycles pc ON pc.id = t1.cycle_id
        WHERE t1.farm_id = $tenantFarmId AND pc.farm_id = $tenantFarmId AND pc.farm_type = 'poultry' AND pc.status = 'active'
    ");
    $cycleRows = $latestBroilerStmt->fetchAll(PDO::FETCH_ASSOC);
    $broilerClosingStock = 0;
    foreach ($cycleRows as $row) {
        $broilerClosingStock += max(0, (float)$row['opening_stock'] - (float)$row['mortality']);
    }
} elseif ($cycleEnabled && $selectedCycleId > 0) {
    $latestBroilerStmt = $pdo->prepare("SELECT opening_stock, mortality FROM broiler_daily_records WHERE cycle_id = ? AND farm_id = ? ORDER BY record_date DESC LIMIT 1");
    $latestBroilerStmt->execute([$selectedCycleId, $tenantFarmId]);
    $latestBroilerRecord = $latestBroilerStmt->fetch();
} elseif (!$cycleEnabled) {
    $latestBroilerStmt = $pdo->query("SELECT opening_stock, mortality FROM broiler_daily_records WHERE farm_id = $tenantFarmId ORDER BY record_date DESC LIMIT 1");
    $latestBroilerRecord = $latestBroilerStmt->fetch();
}
if ($latestBroilerRecord) {
    $broilerClosingStock = $latestBroilerRecord['opening_stock'] - $latestBroilerRecord['mortality'];
}

// Calculate monthly totals
$monthlyTotals = [
    'opening_stock' => 0,
    'mortality' => 0,
    'feed_consumption' => 0,
    'water_consumption' => 0
];

foreach ($records as $record) {
    $monthlyTotals['mortality'] += $record['mortality'];
    $monthlyTotals['feed_consumption'] += $record['feed_consumption_bags'];
    $monthlyTotals['water_consumption'] += $record['water_consumption_liters'];
}

$summaryTotals = $monthlyTotals;
if ($cycleEnabled && $selectedCycleId === 0) {
    $summaryStmt = $pdo->query("
        SELECT
            COALESCE(SUM(mortality), 0) AS mortality,
            COALESCE(SUM(feed_consumption_bags), 0) AS feed_consumption,
            COALESCE(SUM(water_consumption_liters), 0) AS water_consumption
        FROM broiler_daily_records
        WHERE farm_id = $tenantFarmId
    ");
    $summaryTotals = array_merge($summaryTotals, $summaryStmt->fetch(PDO::FETCH_ASSOC) ?: []);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_record'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        http_response_code(419);
        exit('Invalid request token.');
    }
    $parseNumeric = static function ($value): string {
        return str_replace(',', '', trim((string)$value));
    };
    $nonNegative = static function ($value, string $label) use ($parseNumeric): float {
        $raw = $parseNumeric($value);
        if ($raw === '' || !is_numeric($raw) || (float)$raw < 0) {
            throw new InvalidArgumentException($label . ' must be a valid non-negative number.');
        }
        return (float)$raw;
    };
    $recordDate = trim((string)($_POST['record_date'] ?? ''));
    $dateObject = DateTime::createFromFormat('Y-m-d', $recordDate);
    if (!$dateObject || $dateObject->format('Y-m-d') !== $recordDate) {
        $_SESSION['error'] = 'Please provide a valid record date.';
        header('Location: broiler_daily_record.php?month=' . urlencode($yearMonth) . '&cycle_id=' . (int)$selectedCycleId);
        exit();
    }
    $cycleIdForSave = ($cycleEnabled && $selectedCycleId > 0) ? $selectedCycleId : null;
    if ($cycleIdForSave !== null) {
        $cycleCheck = $pdo->prepare("SELECT id, start_date, expected_end_date FROM production_cycles WHERE id = ? AND farm_id = ? AND farm_type = 'poultry' AND production_type = 'broiler' AND status = 'active' LIMIT 1");
        $cycleCheck->execute([$cycleIdForSave, $tenantFarmId]);
        $cycle = $cycleCheck->fetch(PDO::FETCH_ASSOC);
        if (!$cycle || $recordDate < $cycle['start_date'] || (!empty($cycle['expected_end_date']) && $recordDate > $cycle['expected_end_date'])) {
            $_SESSION['error'] = 'The selected broiler cycle is invalid for this record date.';
            header('Location: broiler_daily_record.php?month=' . urlencode($yearMonth) . '&cycle_id=' . (int)$selectedCycleId);
            exit();
        }
    }
    try {
        $openingStock = (int)$nonNegative($_POST['opening_stock'] ?? 0, 'Opening stock');
        $mortality = (int)$nonNegative($_POST['mortality'] ?? 0, 'Mortality');
        $feedConsumption = $nonNegative($_POST['feed_consumption'] ?? 0, 'Feed consumption');
            $feedItemId = (int)($_POST['feed_item_id'] ?? 0);
            if ($feedConsumption > 0 && $feedItemId <= 0) {
                throw new InvalidArgumentException('Please select the feed item used for this daily consumption.');
            }
        $waterConsumption = $nonNegative($_POST['water_consumption'] ?? 0, 'Water consumption');
        $birdsAge = (int)$nonNegative($_POST['birds_age'] ?? 0, 'Bird age');
    } catch (InvalidArgumentException $e) {
        $_SESSION['error'] = $e->getMessage();
        header('Location: broiler_daily_record.php?month=' . urlencode($yearMonth) . '&cycle_id=' . (int)$selectedCycleId);
        exit();
    }
    if ($openingStock < 1 || $birdsAge < 1) {
        $_SESSION['error'] = 'Opening stock and bird age must be greater than zero.';
        header('Location: broiler_daily_record.php?month=' . urlencode($yearMonth) . '&cycle_id=' . (int)$selectedCycleId);
        exit();
    }
    if ($mortality > $openingStock) {
        $_SESSION['error'] = 'Mortality cannot exceed opening stock.';
        header('Location: broiler_daily_record.php?month=' . urlencode($yearMonth) . '&cycle_id=' . (int)$selectedCycleId);
        exit();
    }
    if ($cycleIdForSave !== null) {
        $previousStmt = $pdo->prepare("SELECT opening_stock, mortality FROM broiler_daily_records WHERE farm_id = ? AND cycle_id = ? AND record_date < ? ORDER BY record_date DESC LIMIT 1");
        $previousStmt->execute([$tenantFarmId, $cycleIdForSave, $recordDate]);
        $previous = $previousStmt->fetch(PDO::FETCH_ASSOC);
        if ($previous) {
            $expectedOpening = max(0, (int)$previous['opening_stock'] - (int)$previous['mortality']);
            if ($openingStock !== $expectedOpening) {
                $_SESSION['error'] = "Opening stock must match the previous day's closing flock (expected {$expectedOpening}).";
                header('Location: broiler_daily_record.php?month=' . urlencode($yearMonth) . '&cycle_id=' . (int)$selectedCycleId);
                exit();
            }
        }
        $nextStmt = $pdo->prepare("SELECT opening_stock FROM broiler_daily_records WHERE farm_id = ? AND cycle_id = ? AND record_date > ? ORDER BY record_date ASC LIMIT 1");
        $nextStmt->execute([$tenantFarmId, $cycleIdForSave, $recordDate]);
        $next = $nextStmt->fetch(PDO::FETCH_ASSOC);
        if ($next) {
            $newClosing = max(0, $openingStock - $mortality);
            if ((int)$next['opening_stock'] !== $newClosing) {
                $_SESSION['error'] = "This change would break flock continuity: the next record starts at {$next['opening_stock']}, but this record would close at {$newClosing}.";
                header('Location: broiler_daily_record.php?month=' . urlencode($yearMonth) . '&cycle_id=' . (int)$selectedCycleId);
                exit();
            }
        }
    }

    // Check if record exists
    $checkSql = "SELECT id FROM broiler_daily_records WHERE farm_id = ? AND record_date = ?";
    $checkParams = [$tenantFarmId, $recordDate];
    if ($cycleEnabled && $selectedCycleId > 0) {
        $checkSql .= " AND cycle_id = ?";
        $checkParams[] = $selectedCycleId;
    }
    $checkStmt = $pdo->prepare($checkSql);
    $checkStmt->execute($checkParams);

     $existingRecordId = $checkStmt->fetchColumn();

        $pdo->beginTransaction();
        try {
        if ($existingRecordId) {
        // Update existing record
        $stmt = $pdo->prepare("UPDATE broiler_daily_records SET
            opening_stock = ?, mortality = ?, feed_consumption_bags = ?, feed_item_id = ?,
            water_consumption_liters = ?, medications = ?, birds_age = ?, remarks = ?
            WHERE farm_id = ? AND record_date = ?" . (($cycleEnabled && $selectedCycleId > 0) ? " AND cycle_id = ?" : ""));
        $updateParams = [
            $openingStock,
            $mortality,
            $feedConsumption,
            $feedItemId ?: null,
            $waterConsumption,
            $_POST['medications'],
            $birdsAge,
            $_POST['remarks'],
            $tenantFarmId,
            $recordDate
        ];
        if ($cycleEnabled && $selectedCycleId > 0) {
            $updateParams[] = $selectedCycleId;
        }
        $stmt->execute($updateParams);
    } else {
        // Insert new record
        $stmt = $pdo->prepare("INSERT INTO broiler_daily_records
            (farm_id, cycle_id, record_date, opening_stock, mortality, feed_consumption_bags, feed_item_id,
             water_consumption_liters, medications, birds_age, remarks, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $tenantFarmId,
            $cycleIdForSave,
            $recordDate,
            $openingStock,
            $mortality,
            $feedConsumption,
            $feedItemId ?: null,
            $waterConsumption,
            $_POST['medications'],
            $birdsAge,
            $_POST['remarks'],
            $_SESSION['user_id']
        ]);
    }

    
        $dailyRecordId = $existingRecordId ? (int)$existingRecordId : (int)$pdo->lastInsertId();
        sync_daily_feed_usage($pdo, $tenantFarmId, $dailyRecordId, $feedItemId > 0 ? $feedItemId : null, $feedConsumption, $cycleIdForSave, $recordDate, 'poultry', 'broiler', 'daily_broiler_record');
        $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $_SESSION['error'] = safeUserExceptionMessage($e, 'The daily record could not be saved.');
            header('Location: broiler_daily_record.php?month=' . urlencode($yearMonth) . '&cycle_id=' . (int)$selectedCycleId);
            exit();
        }

$_SESSION['success'] = "Broiler daily record saved successfully!";
    $redirectMonth = date('Y-m', strtotime($recordDate));
    header("Location: broiler_daily_record.php?month=" . $redirectMonth . "&cycle_id=" . (int)$selectedCycleId);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <?php include(__DIR__ . '/../navbar_head.php'); ?>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Broiler Daily Record - Renee Farms</title>
</head>
<body class="poultry-page">
    <?php include(__DIR__ . '/../navbar.php'); ?>

    <div class="container-fluid mt-4 poultry-shell">

        <div class="row">
            <div class="col-12">
                <div class="card poultry-panel">
                    <div class="card-header poultry-hero d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <h4 class="mb-0">
                            <i class="bi bi-calendar-check"></i>
                            Broiler Daily Record - <?php echo date('F Y', strtotime($yearMonth)); ?>
                        </h4>
                        <div class="d-flex flex-wrap gap-2">
                            <input type="date" class="form-control js-calendar-input" id="monthSelector"
                                   value="<?php echo $monthSelectorDate; ?>" style="width: 200px;">
                            <button class="btn btn-primary" onclick="openRecordModal()">
                                <i class="bi bi-plus-circle"></i> Add Today's Record
                            </button>
                        </div>

                    </div>

                    <div class="card-body bg-light">
                        <div class="smart-poultry-note p-3 mb-4 d-flex gap-3 align-items-start">
                            <i class="bi bi-stars fs-4"></i>
                            <div>
                                <div class="fw-bold">Broiler growth intelligence</div>
                                <div class="small">Use daily mortality, feed and water trends as the foundation for FCR, target-weight and health warning alerts.</div>
                            </div>
                        </div>
                        <!-- Monthly Summary -->
                        <div class="row mb-4 g-3">
                            <div class="col-6 col-md-4 col-lg-2">
                                <div class="card text-white" style="background-color: #7c4dff;">
                                    <div class="card-body text-center">
                                        <h6>Current Stock</h6>
                                        <h3><?php echo $broilerClosingStock !== null ? number_format($broilerClosingStock) : '--'; ?></h3>
                                        <small>Latest Closing</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-lg-2">
                                <div class="card text-white bg-primary">
                                    <div class="card-body text-center">
                                        <h6>Total Mortality</h6>
                                        <h3><?php echo number_format($summaryTotals['mortality']); ?></h3>
                                        <?php if ($cycleEnabled && $selectedCycleId === 0): ?>
                                            <small>Birds Lost</small>
                                        <?php else: ?>
                                            <small>This Month</small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-lg-2">
                                <div class="card text-white bg-success">
                                    <div class="card-body text-center">
                                        <h6>Feed Consumed</h6>
                                        <h3><?php echo number_format($summaryTotals['feed_consumption'], 2); ?></h3>
                                        <small>Bags (25kg)</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-lg-2">
                                <div class="card text-white bg-warning">
                                    <div class="card-body text-center">
                                        <h6>Water Consumed</h6>
                                        <h3><?php echo number_format($summaryTotals['water_consumption']); ?></h3>
                                        <small>Liters</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-lg-2">
                                <div class="card text-white bg-info">
                                    <div class="card-body text-center">
                                        <h6>Days Recorded</h6>
                                        <h3><?php echo count($records); ?></h3>
                                        <small>Out of <?php echo date('t', strtotime($yearMonth)); ?> days</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php if ($cycleEnabled): ?>
                        <div class="row mb-3">
                            <div class="col-md-6 col-lg-4">
                                <label class="form-label fw-bold">Active Broiler Cycle</label>
                                <select class="form-select" id="activeCycleSelector">
                                    <option value="0" <?php echo ($selectedCycleId === 0) ? 'selected' : ''; ?>>All / Legacy records</option>
                                    <?php foreach ($activeCycles as $cycle): ?>
                                    <option value="<?php echo (int)$cycle['id']; ?>" <?php echo ((int)$selectedCycleId === (int)$cycle['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($cycle['cycle_code']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php if ($selectedCycleId === 0): ?>
                            <div class="col-12 mt-2">
                                <small class="text-muted">Select a cycle code to load records into the calendar.</small>
                            </div>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>

                        <!-- Calendar View -->
                        <div class="card mb-4">
                            <div class="card-header d-flex align-items-center justify-content-between">
                                <h5 class="mb-0"><i class="bi bi-calendar3 me-2"></i>Monthly Calendar View</h5>
                                <?php if ($selectedCycleId > 0): ?>
                                <span class="badge text-bg-light border">Tap a day to add or edit</span>
                                <?php endif; ?>
                            </div>
                            <div class="card-body <?php echo $selectedCycleId === 0 ? 'calendar-legacy' : ''; ?>">
                                <div class="row">
                                    <?php
                                    // Generate calendar
                                    $firstDay = date('N', strtotime($yearMonth . '-01'));
                                    $daysInMonth = date('t', strtotime($yearMonth));
                                    $currentDay = 1;

                                    // Week days header
                                    $weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                                    ?>

                                    <?php foreach ($weekDays as $day): ?>
                                    <div class="col text-center fw-bold text-muted mb-2 calendar-weekday">
                                        <?php echo $day; ?>
                                    </div>
                                    <?php endforeach; ?>

                                    <!-- Empty cells for first week -->
                                    <?php for ($i = 1; $i < $firstDay; $i++): ?>
                                    <div class="col"></div>
                                    <?php endfor; ?>

                                    <!-- Days of the month -->
                                    <?php while ($currentDay <= $daysInMonth): ?>
                                        <?php if (($currentDay + $firstDay - 2) % 7 == 0 && $currentDay > 1): ?>
                                            </div><div class="row mb-2">
                                        <?php endif; ?>

                                        <?php
                                        $currentDate = $yearMonth . '-' . sprintf('%02d', $currentDay);
                                        $record = null;
                                        $dayRecords = [];
                                        $hasRecord = false;
                                        $hasMortality = false;
                                        $dayOpeningStock = 0;
                                        $dayMortality = 0;
                                        $dayFeedConsumption = 0;

                                        foreach ($records as $rec) {
                                            if (date('Y-m-d', strtotime($rec['record_date'])) == $currentDate) {
                                                $dayRecords[] = $rec;
                                                $record = $rec;
                                                $hasRecord = true;
                                                $dayOpeningStock += (float)$rec['opening_stock'];
                                                $dayMortality += (float)$rec['mortality'];
                                                $dayFeedConsumption += (float)$rec['feed_consumption_bags'];
                                                if ($rec['mortality'] > 0) {
                                                    $hasMortality = true;
                                                }
                                            }
                                        }
                                        ?>

                                        <div class="col p-1">
                                            <?php
                                            $dayClasses = 'calendar-day border rounded p-2 text-center w-100';
                                            if (!$canEdit) {
                                                $dayClasses .= ' no-action';
                                            }
                                            if ($hasRecord) {
                                                $dayClasses .= ' has-record';
                                            }
                                            if ($hasMortality) {
                                                $dayClasses .= ' has-mortality';
                                            }

                                            if ($canEdit && $selectedCycleId > 0) {
                                                $dayClasses .= $hasRecord ? ' edit-record-btn' : ' add-record-btn';
                                            }
                                            ?>
                                            <button type="button"
                                                    class="<?php echo $dayClasses; ?>"
                                                    <?php if (!$canEdit): ?>disabled<?php endif; ?>
                                                    <?php if ($canEdit): ?>
                                                    data-record-date="<?php echo $currentDate; ?>"
                                                    data-selected-date="<?php echo $currentDate; ?>"
                                                    <?php if ($hasRecord && $record): ?>
                                                    data-opening-stock="<?php echo htmlspecialchars($record['opening_stock']); ?>"
                                                    data-mortality="<?php echo htmlspecialchars($record['mortality']); ?>"
                                                    data-feed-consumption="<?php echo htmlspecialchars($record['feed_consumption_bags']); ?>"
                                                                data-feed-item-id="<?php echo (int)($record['feed_item_id'] ?? 0); ?>"
                                                    data-water-consumption="<?php echo htmlspecialchars($record['water_consumption_liters']); ?>"
                                                    data-medications="<?php echo htmlspecialchars($record['medications']); ?>"
                                                    data-birds-age="<?php echo htmlspecialchars($record['birds_age']); ?>"
                                                    data-remarks="<?php echo htmlspecialchars($record['remarks']); ?>"
                                                    <?php endif; ?>
                                                    <?php endif; ?>>
                                                <div class="calendar-date"><?php echo $currentDay; ?></div>
                                                <?php if ($hasRecord): ?>
                                                <div class="calendar-meta"><?php echo count($dayRecords); ?> record(s)</div>
                                                <?php if ($selectedCycleId > 0): ?>
                                                <div class="d-flex flex-wrap gap-1 justify-content-center mt-1">
                                                    <span class="badge text-bg-primary">O/S: <?php echo number_format($dayOpeningStock, 0); ?></span>
                                                    <span class="badge text-bg-danger">Mort: <?php echo number_format($dayMortality, 0); ?></span>
                                                    <span class="badge text-bg-success">Feed: <?php echo number_format($dayFeedConsumption, 1); ?></span>
                                                </div>
                                                <?php endif; ?>
                                                <?php else: ?>
                                                <div class="calendar-meta">No record</div>
                                                <?php endif; ?>
                                            </button>
                                        </div>

                                        <?php $currentDay++; ?>
                                    <?php endwhile; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Records Table -->
                        <div class="card">
                            <div class="card-header">
                                <h5>Detailed Daily Records</h5>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover poultry-table">
                                        <thead class="table-dark">
                                            <tr>
                                                <th>Date</th>
                                                <th>Opening Stock</th>
                                                <th>Mortality</th>
                                                <th>Feed (bags)</th>
                                                <th>Water (L)</th>
                                                <th>Medications</th>
                                                <th>Birds Age</th>
                                                <th>Remarks</th>
                                                <?php if ($canEdit): ?>
                                                <th>Actions</th>
                                                <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($records)): ?>
                                            <tr>
                                                <td colspan="<?php echo ($canEdit || $canDelete) ? '9' : '8'; ?>" class="text-center text-muted py-4">
                                                    <i class="bi bi-inbox display-4 d-block mb-2"></i>
                                                    No records found for this month
                                                </td>
                                            </tr>
                                            <?php else: ?>
                                                <?php foreach ($records as $record):
                                                    $closingStock = $record['opening_stock'] - $record['mortality'];
                                                ?>
                                                <tr>
                                                    <td>
                                                        <strong><?php echo date('d/m/Y', strtotime($record['record_date'])); ?></strong>
                                                    </td>
                                                    <td><?php echo $record['opening_stock']; ?></td>
                                                    <td class="text-danger fw-bold">
                                                        <?php echo $record['mortality']; ?>
                                                        <small class="d-block text-muted">
                                                            Closing: <?php echo $closingStock; ?>
                                                        </small>
                                                    </td>
                                                    <td><?php echo $record['feed_consumption_bags']; ?></td>
                                                    <td><?php echo number_format($record['water_consumption_liters']); ?></td>
                                                    <td>
                                                        <?php if ($record['medications']): ?>
                                                        <small><?php echo substr($record['medications'], 0, 20); ?>...</small>
                                                        <?php else: ?>
                                                        <span class="text-muted">--</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $record['birds_age']; ?> days
                                                    </td>
                                                    <td>
                                                        <?php if ($record['remarks']): ?>
                                                        <small class="text-muted"><?php echo substr($record['remarks'], 0, 30); ?>...</small>
                                                        <?php else: ?>
                                                        <span class="text-muted">--</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <?php if ($canEdit || $canDelete): ?>
                                                    <td>
                                                        <?php if ($canEdit): ?>
                                                        <button class="btn btn-sm btn-outline-primary edit-record-btn"
                                                                title="Edit Record"
                                                                data-record-date="<?php echo htmlspecialchars($record['record_date']); ?>"
                                                                data-selected-date="<?php echo htmlspecialchars($record['record_date']); ?>"
                                                                data-opening-stock="<?php echo htmlspecialchars($record['opening_stock']); ?>"
                                                                data-mortality="<?php echo htmlspecialchars($record['mortality']); ?>"
                                                                data-feed-consumption="<?php echo htmlspecialchars($record['feed_consumption_bags']); ?>"
                                                                data-feed-item-id="<?php echo (int)($record['feed_item_id'] ?? 0); ?>"
                                                                data-water-consumption="<?php echo htmlspecialchars($record['water_consumption_liters']); ?>"
                                                                data-medications="<?php echo htmlspecialchars($record['medications']); ?>"
                                                                data-birds-age="<?php echo htmlspecialchars($record['birds_age']); ?>"
                                                                data-remarks="<?php echo htmlspecialchars($record['remarks']); ?>">
                                                            <i class="bi bi-pencil"></i>
                                                        </button>
                                                        <?php endif; ?>
                                                        <?php if ($canDelete): ?>
                                                        <button class="btn btn-sm btn-outline-danger ms-1"
                                                                type="button"
                                                                title="Delete Record"
                                                                onclick="deleteBroilerDailyRecord(<?php echo (int)$record['id']; ?>)">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                        <?php endif; ?>
                                                    </td>
                                                    <?php endif; ?>
                                                </tr>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                        <tfoot class="table-secondary">
                                            <tr>
                                                <td><strong>TOTAL</strong></td>
                                                <td>--</td>
                                                <td class="text-danger fw-bold"><?php echo $monthlyTotals['mortality']; ?></td>
                                                <td class="fw-bold"><?php echo number_format($monthlyTotals['feed_consumption'], 2); ?></td>
                                                <td class="fw-bold"><?php echo number_format($monthlyTotals['water_consumption']); ?></td>
                                                <td colspan="<?php echo ($canEdit || $canDelete) ? '4' : '3'; ?>">Monthly Summary</td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Record Modal -->
    <div class="modal fade" id="recordModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" id="recordForm">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES); ?>">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalTitle">Broiler Daily Record</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="record_date" id="recordDate">
                        <input type="hidden" name="cycle_id" value="<?php echo (int)$selectedCycleId; ?>">

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Date</label>
                                <input type="date" class="form-control" id="selectedDate"
                                       onchange="checkExistingRecord()" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Birds Age (days)</label>
                                <input type="number" name="birds_age" class="form-control"
                                       id="birdsAge" min="1" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Opening Stock</label>
                                <input type="number" name="opening_stock" class="form-control"
                                       id="openingStock" min="0" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Mortality</label>
                                <input type="number" name="mortality" class="form-control"
                                       id="mortality" min="0" value="0">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Feed Consumption (25kg/bag)</label>
                                <input type="number" name="feed_consumption" class="form-control"
                                       id="feedConsumption" step="0.01" min="0" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Feed Item</label>
                                <select name="feed_item_id" id="feedItemId" class="form-select">
                                    <option value="">Select active feed item</option>
                                    <?php foreach ($dailyFeedItems as $feedItem): ?>
                                        <option value="<?php echo (int)$feedItem['id']; ?>" data-unit="<?php echo htmlspecialchars($feedItem['unit'], ENT_QUOTES); ?>">
                                            <?php echo htmlspecialchars($feedItem['item_name']); ?> (<?php echo htmlspecialchars($feedItem['unit']); ?> — <?php echo number_format((float)$feedItem['current_stock'], 2); ?> available)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                
                                <small class="text-muted">Select the active feed used for this day's consumption. Inventory stock is updated automatically.</small>
                            </div>
<div class="col-md-6 mb-3">
                                <label>Water Consumption (liters)</label>
                                <input type="number" name="water_consumption" class="form-control"
                                       id="waterConsumption" step="0.1" min="0" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label>Medications</label>
                            <textarea name="medications" class="form-control"
                                     id="medications" rows="2"></textarea>
                        </div>

                        <div class="mb-3">
                            <label>Remarks / Causes of Mortality</label>
                            <textarea name="remarks" class="form-control"
                                     id="remarks" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="save_record" class="btn btn-primary">Save Record</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

   <script src="<?php echo BASE_URL; ?><?php echo versioned_asset('/assets/vendor/jquery/jquery.min.js'); ?>"></script>
    <script src="<?php echo BASE_URL; ?><?php echo versioned_asset('/assets/vendor/bootstrap5/js/bootstrap.bundle.min.js'); ?>"></script>
    <script src="<?php echo BASE_URL; ?><?php echo versioned_asset('/assets/vendor/datatables/js/jquery.dataTables.min.js'); ?>"></script>
    <script src="<?php echo BASE_URL; ?><?php echo versioned_asset('/assets/vendor/datatables/js/dataTables.bootstrap5.min.js'); ?>"></script>
    <script src="<?php echo BASE_URL; ?><?php echo versioned_asset('/assets/vendor/datatables-responsive/js/dataTables.responsive.min.js'); ?>"></script>
    <script src="<?php echo BASE_URL; ?><?php echo versioned_asset('/assets/js/main.js'); ?>"></script>
 <script src="<?php echo BASE_URL; ?>/assets/js/edit-modal.js"></script>
    <script>
    // Month selector
document.getElementById('monthSelector').addEventListener('blur', function() {
    window.location.href = 'broiler_daily_record.php?month=' + this.value.substring(0, 7) + '&cycle_id=<?php echo (int)$selectedCycleId; ?>';
});
const cycleSelector = document.getElementById('activeCycleSelector');
if (cycleSelector) {
    cycleSelector.addEventListener('change', function () {
        window.location.href = 'broiler_daily_record.php?month=<?php echo $yearMonth; ?>&cycle_id=' + this.value;
    });
}


    const selectedCycleId = <?php echo (int)$selectedCycleId; ?>;
    const canEditRetrievedOpeningStock = <?php echo (isPlatformOwner() || hasRole('farm_admin')) ? 'true' : 'false'; ?>;
    function lockRetrievedOpeningStock() {
        if (!canEditRetrievedOpeningStock) {
            document.getElementById('openingStock').readOnly = true;
        }
    }
    function unlockOpeningStock() {
        document.getElementById('openingStock').readOnly = false;
    }

    // Open modal for new record
    function openRecordModal(date = null, hasRecord = false) {
        const modalElement = document.getElementById('recordModal');
        const modal = bootstrap.Modal.getOrCreateInstance(modalElement);
        const today = new Date().toISOString().split('T')[0];
        const selectedDate = date || today;

        resetForm();

        document.getElementById('selectedDate').value = selectedDate;
        document.getElementById('recordDate').value = selectedDate;

        if (hasRecord) {
            document.getElementById('modalTitle').textContent = 'Edit Record';
        } else {
            document.getElementById('modalTitle').textContent = 'Add Daily Record';
            loadExistingRecordOrPreviousStock(selectedDate, 'Add Daily Record');
        }

        modal.show();
    }

    function loadExistingRecordOrPreviousStock(date, addTitle) {
        if (selectedCycleId <= 0) {
            document.getElementById('modalTitle').textContent = addTitle;
            return;
        }

        fetch(`../api/check_record.php?type=broiler&date=${date}&cycle_id=${selectedCycleId}`)
            .then(response => response.json())
            .then(data => {
                if (data.exists) {
                    document.getElementById('modalTitle').textContent = 'Edit Record';
                    fetchRecordData(date);
                    return;
                }

                document.getElementById('modalTitle').textContent = addTitle;
                fetchPreviousStock(date);
            })
            .catch(error => {
                console.error(error);
            });
    }

    // Fetch record data
    function fetchRecordData(date) {
        fetch(`../api/get_record.php?type=broiler&date=${date}&cycle_id=${selectedCycleId}`)
            .then(response => response.json())
            .then(payload => {
                if (payload && payload.success === false) {
                    throw new Error(payload.error || 'Failed to fetch record');
                }
                const data = payload ? payload.data : null;
                if (data) {
                    document.getElementById('birdsAge').value = data.birds_age || '';
                    document.getElementById('openingStock').value = data.opening_stock || '';
                    document.getElementById('mortality').value = data.mortality || 0;
                    document.getElementById('feedConsumption').value = data.feed_consumption_bags || '';
                    if (document.getElementById('feedItemId')) document.getElementById('feedItemId').value = data.feed_item_id || '';
                    document.getElementById('waterConsumption').value = data.water_consumption_liters || '';
                    document.getElementById('medications').value = data.medications || '';
                    document.getElementById('remarks').value = data.remarks || '';
                }
            })
            .catch(error => {
                console.error(error);
            });
    }

    // Fetch latest earlier closing stock
    function fetchPreviousStock(selectedDate) {
        fetch(`../api/get_previous_stock.php?type=broiler&date=${selectedDate}&cycle_id=${selectedCycleId}`)
            .then(response => response.json())
            .then(payload => {
                if (payload && payload.success === false) {
                    throw new Error(payload.error || 'Failed to fetch previous record');
                }
                if (payload && payload.closing_stock !== null && payload.closing_stock !== undefined) {
                    document.getElementById('openingStock').value = payload.closing_stock > 0 ? payload.closing_stock : '';
                    lockRetrievedOpeningStock();
                }
            })
            .catch(error => {
                console.error(error);
            });
    }

    // Check existing record
    function checkExistingRecord() {
        const date = document.getElementById('selectedDate').value;
        document.getElementById('recordDate').value = date;
        if (selectedCycleId <= 0) {
            resetForm();
            document.getElementById('selectedDate').value = date;
            document.getElementById('recordDate').value = date;
            return;
        }

        fetch(`../api/check_record.php?type=broiler&date=${date}&cycle_id=${selectedCycleId}`)
            .then(response => response.json())
            .then(data => {
                if (data.exists) {
                    document.getElementById('modalTitle').textContent = 'Edit Record';
                    fetchRecordData(date);
                } else {
                    document.getElementById('modalTitle').textContent = 'Add Daily Record';
                    resetForm();

                    document.getElementById('selectedDate').value = date;
                    document.getElementById('recordDate').value = date;

                    fetchPreviousStock(date);
                }
            });
    }

    // Reset form
    function resetForm() {
        unlockOpeningStock();
        document.getElementById('recordForm').reset();
        document.getElementById('mortality').value = 0;
    }

    // Attach edit modals
    attachEditModal({
        buttonSelector: '.edit-record-btn',
        modalSelector: '#recordModal',
        fieldMap: {
            recordDate: '#recordDate',
            selectedDate: '#selectedDate',
            birdsAge: '#birdsAge',
            openingStock: '#openingStock',
            mortality: '#mortality',
            feedConsumption: '#feedConsumption',
            feedItemId: '#feedItemId',
            waterConsumption: '#waterConsumption',
            medications: '#medications',
            remarks: '#remarks'
        },
        onShow: ({ modalElement }) => {
            modalElement.querySelector('#modalTitle').textContent = 'Edit Record';
        }
    });

    // Add record from calendar
    document.querySelectorAll('.add-record-btn').forEach(button => {
        button.addEventListener('click', () => {
            openRecordModal(button.dataset.recordDate, false);
        });
    });

    // Show messages
    
    <?php if ($canDelete): ?>
    async function deleteBroilerDailyRecord(recordId) {
        const confirmed = await AppConfirm.ask('Are you sure you want to delete this record? This action cannot be undone.', {title:'Delete daily record?', confirmText:'Delete'});
        if (!confirmed) return;
        try {
            const params = new URLSearchParams({ type: 'broiler', id: recordId, csrf_token: '<?php echo csrf_token(); ?>' });
            const response = await fetch('../api/delete_record.php', { method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded'}, body: params.toString() });
            const data = await response.json().catch(() => ({}));
            if (response.ok && data.success) {
                AppNotify.success('Broiler daily record deleted successfully.');
                setTimeout(() => location.reload(), 700);
            } else {
                AppNotify.error(data.error || data.message || 'Unable to delete broiler daily record.');
            }
        } catch (error) {
            AppNotify.error('Unable to delete broiler daily record. Please try again.');
        }
    }
    <?php endif; ?>
</script>
</body>
</html>
